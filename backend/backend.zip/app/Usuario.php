<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Usuario extends Model
{
    //Relaciones
    // public function empresa(){
    //     //Vamos a devolver todos los datos del usuario que ha creado el registro
    //     return $this->belongsTo('App\Cliente', 'id_empresa');
    // }
}
